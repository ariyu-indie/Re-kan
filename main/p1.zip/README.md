hello, i made this project in December 21!
# how to use

go to the folder of your rekan (make sure it shows no html, just the main folder)

```
rekan (you should be here, and should see main.)
|_ main
  |_ files...
```

(if you have no folder, unzip from a package.)
then, use http-server to the current directory

if you have none
do this
```
npm install -g http-server
```
then try again.
```
http-server
```
it should show the link to where the project is being ran
if so, go to that link, and have fun.

if you're on android
it's even better to use "SHTTPS" an android app, it's free, and is easy to use.